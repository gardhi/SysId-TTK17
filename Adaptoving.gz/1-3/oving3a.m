phi1sum = [-Y(1)-Y(2);-Y(1);U(1)+U(2);U(1);0]*Y(1)*Y(2)*Y(3);
phi2sum = [-Y(1)-Y(2);-Y(1);U(1)+U(2);U(1);0]*[-Y(1)-Y(2);-Y(1);U(1)+U(2);U(1);0]';
%hold on;
theta = zeros(5,1);
for j=4:10000,
    %theta is the theta for the particular n in thetaN phi1sum is the sum
    %of phi and y. phi2sum is the sum of phitranspose and phi

    phi1 = [-Y(j-1);-Y(j-2);U(j-1);U(j-2);U(j-3)]*Y(j);
    phi2 = [-Y(j-1);-Y(j-2);U(j-1);U(j-2);U(j-3)]*[-Y(j-1);-Y(j-2);U(j-1);U(j-2);U(j-3)]';
    phi1sum= phi1sum + phi1;
    phi2sum = phi2sum + phi2;
    if (j>=10),
        theta = inv(phi2sum/j)*phi1sum/j;
        %plot(j,theta);
    end
    
end

%hold off;

Phi1sum = zeros(5,1);
Phi2sum = zeros(5,5);
x = zeros(10000,1);
Theta = zeros(5,1);

x(1) = [0;0;0;0;0]'*theta;

x(2) = [-x(1);0;U(1);0;0]'*theta;

x(3) =[-x(2);-x(1);U(2);U(1);0]'*theta;


    

hold on;

for j=4:10000,
    x(j) = [-x(j-1);-x(j-2);U(j-1);U(j-2);U(j-3)]'*theta;
  
    Phi1 = [-x(j-1);-x(j-2);U(j-1);U(j-2);U(j-3)]*x(j);
    Phi2 = [-x(j-1);-x(j-2);U(j-1);U(j-2);U(j-3)]*[-Y(j-1);-Y(j-2);U(j-1);U(j-2);U(j-3)]';
    Phi1sum= Phi1sum + Phi1;
    Phi2sum = Phi2sum + Phi2;
    if (j>=10),
        Theta = inv(Phi2sum/j)*Phi1sum/j;
        plot(j,Theta);
    end
end

hold off;
    