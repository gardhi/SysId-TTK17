clear all;
clc;
close all;
%sub n means negative or i-1 sub p means positive or i+1

load subdata.mat

i = (length(U)+1)/4;

%create hankel matrix and submatrices
U_hankel = hankel(U(1:(2*i)), U((2*i):(4*i-1)));
Y_hankel = hankel(Y(1:(2*i)), Y((2*i):(4*i-1)));

U_p = U_hankel((1:i),:);
U_f = U_hankel(((i+1):(2*i)),:);
U_pp = U_hankel((1:(i+1)),:);
U_fn = U_hankel((i+2:(2*i)),:);

Y_p = Y_hankel((1:i),:);
Y_f = Y_hankel(((i+1):(2*i)),:);
Y_pp = Y_hankel((1:(i+1)),:);
Y_fn = Y_hankel(((i+2):(2*i)),:);

W_p = [U_p;Y_p];
W_pp = [U_pp;Y_pp];

%do the oblique projection
O_i = oblique_projection(Y_f,W_p,U_f);

%singular value decomposition
[u,s,v] = svd(O_i);

%plot the singular values
x = diag(s);
hold on;
for i=1:length(x),
    plot(i,x(i),'.','markersize',20);
end
hold off;

%choose degree based on plot
dyn_deg = input('what is the dynamic degree based on the plot?: ');
close all;


U_1 = u(:,1:dyn_deg);
U_2 = u(:,(dyn_deg+1):end);

%S = diag(s);
S_1 = diag(s);
S_1 = S_1(1:dyn_deg);
S_1 = diag(S_1);
S_2 = diag(s);
S_2 = S_2((dyn_deg+1):end);
S_2 = diag(S_2);

V_1 = v(:,1:dyn_deg);
V_2 = v(:,(dyn_deg+1):end);

%check if right partitioning
%O_i_try = [U_1 U_2]*diag(S)*[V_1';V_2'];
%if O_i == O_i_try
%    fprintf('riktig')
%end

%create gamma and X
X_i = sqrt(S_1)*V_1';
gamma_i = U_1*sqrt(S_1);

%create gammaneg and xneg and O_ineg
% G)
O_i_n = oblique_projection(Y_fn,W_pp,U_fn);

% H)


gamma_in = gamma_i(1:(end-1),:);
gamma_in_ps = pinv(gamma_in);
X_ip = gamma_in_ps*O_i_n;


%this is now a least squares problem to find A,B,C,D
% J)
U_i = U_hankel(i+1,:);
Y_i = Y_hankel(i+1,:);
ABCD = [X_ip;Y_i]*pinv([X_i;U_i]);

A = ABCD(1:dyn_deg,1:dyn_deg);
B = ABCD(1:dyn_deg,dyn_deg+1);
C = ABCD(dyn_deg+1,1:dyn_deg);
D = ABCD(dyn_deg+1,dyn_deg+1);


% K)
Y_hatt = zeros(1,length(U));
X_hatt = zeros(dyn_deg, length(U));
for i=1:399,
    Y_hatt(i) = C*X_hatt(:,i) + D*U(i);
    X_hatt(:,i+1) = A*X_hatt(:,i) + B*U(i);
end
%plot estimated vs Y
t = 1:length(U);
plot(t,Y_hatt',t,Y)




% 3. dynamic order is 2, seen from the plot of S


%4. The statespace matrixes are not unique and can be transformed to an
%infite different choices which all are true

