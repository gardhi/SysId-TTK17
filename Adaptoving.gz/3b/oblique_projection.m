function [op] = oblique_projection(A,C,B)
r = size(C,1);
psInvMatrix = [C*C' C*B'; B*C' B*B'];
psInv = pinv(psInvMatrix); % do the pseudo inverse
psInv = psInv(:,(1:r)); %slice first r columns
op = A*[C' B']*psInv*C;
end

%O_i = oblique_projection(Y_f,W_p,U_f);